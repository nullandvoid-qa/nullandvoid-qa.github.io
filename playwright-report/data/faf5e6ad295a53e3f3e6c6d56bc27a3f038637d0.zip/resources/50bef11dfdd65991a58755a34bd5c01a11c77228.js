/**
 * Google OAuth2 Authentication Module
 * Handles login/logout and stores user info locally
 * @global google - Google Sign-In API
 * @global jwt_decode - JWT decoding library
 */

/* global google, jwt_decode */

(function() {
  'use strict';

  // Configuration
  const GOOGLE_CLIENT_ID = '891864212965-ka68deqed5he142866v3eul9f7plq19k.apps.googleusercontent.com'; // User must set this
  const GOOGLE_SIGNIN_URL = 'https://accounts.google.com/gsi/client';
  const STORAGE_KEY_USER = 'nv_auth_user';
  const STORAGE_KEY_TOKEN = 'nv_auth_token';
  const STORAGE_KEY_PROGRESS_SUFFIX = '_progress'; // user_id + suffix
  // guest login removed; anonymous progress will use a shared anonymous key

  function readStoredJson(key, fallback = {}) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      console.error('Failed to parse storage value:', e);
      return fallback;
    }
  }

  function saveStoredJson(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.error('Failed to save storage value:', e);
      return false;
    }
  }

  function loadGoogleSignInScript() {
    return new Promise((resolve) => {
      if (window.google && window.google.accounts) return resolve(true);
      const existing = document.querySelector(`script[src="${GOOGLE_SIGNIN_URL}"]`);
      if (existing) {
        existing.addEventListener('load', () => resolve(true));
        existing.addEventListener('error', () => resolve(false));
        return;
      }
      const script = document.createElement('script');
      script.src = GOOGLE_SIGNIN_URL;
      script.async = true;
      script.defer = true;
      script.addEventListener('load', () => resolve(true));
      script.addEventListener('error', () => resolve(false));
      document.head.appendChild(script);
    });
  }

  function triggerPostLogoutReload() {
    if (window.__NVAuthReload && typeof window.__NVAuthReload === 'function') {
      window.__NVAuthReload();
      return;
    }

    if (window.location && typeof window.location.reload === 'function') {
      window.location.reload();
    }
  }

  // Export to global, but preserve any preconfigured auth object used by tests or environment.
  window.NVAuth = (typeof window.NVAuth === 'object' && window.NVAuth !== null) ? window.NVAuth : {};
  if (typeof window.NVAuth.user === 'undefined') window.NVAuth.user = null;
  if (typeof window.NVAuth.isAuthenticated !== 'boolean') window.NVAuth.isAuthenticated = false;
  if (typeof window.NVAuth.init !== 'function') window.NVAuth.init = init;
  if (typeof window.NVAuth.getUser !== 'function') window.NVAuth.getUser = getUser;
  if (typeof window.NVAuth.getUserName !== 'function') window.NVAuth.getUserName = getUserName;
  if (typeof window.NVAuth.getProgress !== 'function') window.NVAuth.getProgress = getProgress;
  if (typeof window.NVAuth.setProgress !== 'function') window.NVAuth.setProgress = setProgress;
  if (typeof window.NVAuth.logout !== 'function') window.NVAuth.logout = logout;
  if (typeof window.NVAuth.getStorageKey !== 'function') window.NVAuth.getStorageKey = getStorageKey;
  if (typeof window.NVAuth.getReadBooks !== 'function') window.NVAuth.getReadBooks = getReadBooks;
  if (typeof window.NVAuth.markAsRead !== 'function') window.NVAuth.markAsRead = markAsRead;
  if (typeof window.NVAuth.unmarkAsRead !== 'function') window.NVAuth.unmarkAsRead = unmarkAsRead;
  if (typeof window.NVAuth.isBookRead !== 'function') window.NVAuth.isBookRead = isBookRead;

  /**
   * Initialize Google Sign-In
   */
  function getAuthActionsContainer() {
    const signinDiv = document.getElementById('auth-signin');
    if (!signinDiv) return null;

    let actions = signinDiv.querySelector('.auth-actions');
    if (!actions) {
      actions = document.createElement('div');
      actions.className = 'auth-actions';
      signinDiv.appendChild(actions);
    }

    return actions;
  }

  function init() {
    // Check if already logged in
    const savedUser = localStorage.getItem(STORAGE_KEY_USER);
    if (savedUser) {
      try {
        window.NVAuth.user = JSON.parse(savedUser);
        window.NVAuth.isAuthenticated = true;
        renderAuthUI();
        return;
      } catch (e) {
        console.error('Failed to restore user session:', e);
        localStorage.removeItem(STORAGE_KEY_USER);
      }
    }

    // Initialize Google Sign-In button
    const initializeGoogleSignIn = () => {
      try {
        const signinDiv = document.getElementById('auth-signin');
        if (!signinDiv) return;

        google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: handleCredentialResponse,
          auto_select: false,
        });

        const actionsContainer = getAuthActionsContainer();
        if (!actionsContainer) return;

        actionsContainer.innerHTML = '';
        const googleButtonWrapper = document.createElement('div');
        googleButtonWrapper.className = 'auth-google-button';
        actionsContainer.appendChild(googleButtonWrapper);

        google.accounts.id.renderButton(
          googleButtonWrapper,
          {
            theme: 'outline',
            size: 'large',
            text: 'signin',
            logo_alignment: 'left',
          }
        );
      } catch (e) {
        console.error('Google Sign-In initialization failed:', e);
        showAuthError('Google Sign-In não disponível');
      }
    };

    if (window.google && window.google.accounts) {
      initializeGoogleSignIn();
    } else {
      loadGoogleSignInScript().then((loaded) => {
        if (loaded && window.google && window.google.accounts) {
          initializeGoogleSignIn();
        } else {
          console.warn('Google Sign-In library failed to load or is unavailable.');
          showAuthError('Google Sign-In não disponível');
        }
      });
    }

    renderAuthUI();
  }

  // Guest/local-signin flow removed. No local guest button is rendered.

  /**
   * Handle Google Sign-In response
   */
  function decodeJwtToken(token) {
    if (typeof jwt_decode !== 'undefined') {
      return jwt_decode(token);
    }

    const parts = String(token).split('.');
    if (parts.length !== 3) {
      throw new Error('Invalid JWT token');
    }

    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => `%${`00${c.charCodeAt(0).toString(16)}`.slice(-2)}`)
        .join(''),
    );

    return JSON.parse(jsonPayload);
  }

  function handleCredentialResponse(response) {
    if (!response.credential) {
      console.error('No credential received');
      return;
    }

    try {
      // Decode JWT token
      const decoded = decodeJwtToken(response.credential);

      // Store user info (only public data)
      const user = {
        id: decoded.sub, // Unique Google ID (not email, safer)
        name: decoded.name || 'User',
        picture: decoded.picture || '',
        email: decoded.email || '', // Store for reference but never expose
        iat: decoded.iat,
      };

      window.NVAuth.user = user;
      window.NVAuth.isAuthenticated = true;

      // Save only the minimal session payload locally.
      // Avoid persisting the raw credential token when not strictly needed.
      saveStoredJson(STORAGE_KEY_USER, user);
      localStorage.removeItem(STORAGE_KEY_TOKEN);

      // Trigger custom event for other modules
      document.dispatchEvent(new CustomEvent('nvauth:login', { detail: user }));

      renderAuthUI();
      showToast(`Bem-vindo, ${user.name}!`);
    } catch (e) {
      console.error('Failed to decode credential:', e);
      showAuthError('Falha ao processar login');
    }
  }

  /**
   * Logout user
   */
  function logout() {
    window.NVAuth.user = null;
    window.NVAuth.isAuthenticated = false;

    localStorage.removeItem(STORAGE_KEY_USER);
    localStorage.removeItem(STORAGE_KEY_TOKEN);

    // Google logout
    if (window.google && window.google.accounts) {
      google.accounts.id.disableAutoSelect();
    }

    document.dispatchEvent(new CustomEvent('nvauth:logout'));

    showToast('Desconectado com sucesso');

    // Ensure the login UI is restored after logout.
    // If the auth button disappears due to UI state sync issues,
    // refresh the page so the app reinitializes cleanly.
    if (window.location && typeof window.location.reload === 'function') {
      triggerPostLogoutReload();
      return;
    }

    renderAuthUI();
  }

  /**
   * Render auth UI based on login state
   */
  function renderAuthUI() {
    const signinDiv = document.getElementById('auth-signin');
    const userDiv = document.getElementById('auth-user');

    if (!signinDiv || !userDiv) return;

    if (window.NVAuth.isAuthenticated && window.NVAuth.user) {
      signinDiv.classList.add('hidden');
      userDiv.classList.remove('hidden');

      document.getElementById('auth-name').textContent = window.NVAuth.user.name;
      const picture = document.getElementById('auth-picture');
      if (picture) {
        if (window.NVAuth.user.picture) {
          picture.src = window.NVAuth.user.picture;
        } else {
          picture.src = '';
        }
      }
        // Replace image avatar with emoji for a consistent, lightweight avatar
        let emoji = document.getElementById('auth-emoji');
        if (!emoji) {
          emoji = document.createElement('span');
          emoji.id = 'auth-emoji';
          emoji.className = 'auth-emoji';
          const nameEl = document.getElementById('auth-name');
          if (nameEl) userDiv.insertBefore(emoji, nameEl);
          else userDiv.insertBefore(emoji, document.getElementById('auth-logout'));
        }
        emoji.textContent = '👤';
        if (picture) picture.style.display = 'none';
    } else {
      signinDiv.classList.remove('hidden');
      userDiv.classList.add('hidden');
    }
  }

  /**
   * Get current user
   */
  function getUser() {
    return window.NVAuth.user;
  }

  /**
   * Get current user name
   */
  function getUserName() {
    if (!window.NVAuth.isAuthenticated || !window.NVAuth.user) {
      return null;
    }
    return window.NVAuth.user.name || null;
  }

  /**
   * Get user's progress from localStorage
   */
  function getProgress() {
    const key = getStorageKey();
    return readStoredJson(key, {});
  }

  /**
   * Save user's progress to localStorage
   */
  function setProgress(progressData) {
    const key = getStorageKey();
    return saveStoredJson(key, progressData);
  }

  /**
   * Get localStorage key for user progress
   */
  function getStorageKey() {
    if (!window.NVAuth.user) return `nv_anonymous${STORAGE_KEY_PROGRESS_SUFFIX}`;
    return `nv_${window.NVAuth.user.id}${STORAGE_KEY_PROGRESS_SUFFIX}`;
  }

  /**
   * Show toast notification
   */
  function showToast(message) {
    if (typeof window.showToast === 'function') {
      window.showToast(message);
      return;
    }

    const toast = document.getElementById('toast');
    if (!toast) return;
    if (!showToast.queue) showToast.queue = [];
    showToast.queue.push(message);
    if (showToast.isShowing) return;

    const showNext = () => {
      if (!showToast.queue.length) {
        showToast.isShowing = false;
        return;
      }
      const nextMessage = showToast.queue.shift();
      toast.textContent = nextMessage;
      toast.classList.add('show');
      showToast.isShowing = true;
      clearTimeout(showToast.timer);
      showToast.timer = setTimeout(() => {
        toast.classList.remove('show');
        showToast.isShowing = false;
        showNext();
      }, 3000);
    };

    showNext();
  }

  /**
   * Show auth error
   */
  function showAuthError(message) {
    showToast(message);
  }

  /**
   * Attach logout button listener
   */
  function attachLogoutListener() {
    const logoutBtn = document.getElementById('auth-logout');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', logout);
    }
  }

  /**
   * Setup when DOM is ready
   */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', attachLogoutListener);
  } else {
    attachLogoutListener();
  }

  // Auto-init when script loads
  function bootstrapAuth() {
    if (window.google && window.google.accounts) {
      init();
      return;
    }

    loadGoogleSignInScript().then((loaded) => {
      if (loaded && window.google && window.google.accounts) {
        init();
      } else {
        console.warn('Google Sign-In library failed to load or is unavailable.');
        init();
      }
    });
  }

  if (document.readyState === 'complete') {
    bootstrapAuth();
  } else {
    window.addEventListener('load', bootstrapAuth);
  }

  /**
   * Get all read books for current user
   * @returns {Object} Map of book IDs to read status
   */
  function getReadBooks() {
    const key = window.NVAuth.user ? `nv_${window.NVAuth.user.id}_read_books` : `nv_anonymous_read_books`;
    return readStoredJson(key, {});
  }

  /**
   * Mark a book as read
   * @param {string} bookId - Book ID
   * @returns {boolean} Success status
   */
  function markAsRead(bookId) {
    try {
      const readBooks = getReadBooks();
      readBooks[bookId] = {
        readAt: new Date().toISOString(),
        completed: true,
      };
      const key = window.NVAuth.user ? `nv_${window.NVAuth.user.id}_read_books` : `nv_anonymous_read_books`;
      saveStoredJson(key, readBooks);
      document.dispatchEvent(new CustomEvent('nvauth:bookmarked', { detail: { bookId, marked: true } }));
      return true;
    } catch (e) {
      console.error('Failed to mark book as read:', e);
      return false;
    }
  }

  /**
   * Unmark a book as read
   * @param {string} bookId - Book ID
   * @returns {boolean} Success status
   */
  function unmarkAsRead(bookId) {
    try {
      const readBooks = getReadBooks();
      delete readBooks[bookId];
      const key = window.NVAuth.user ? `nv_${window.NVAuth.user.id}_read_books` : `nv_anonymous_read_books`;
      saveStoredJson(key, readBooks);
      document.dispatchEvent(new CustomEvent('nvauth:bookmarked', { detail: { bookId, marked: false } }));
      return true;
    } catch (e) {
      console.error('Failed to unmark book as read:', e);
      return false;
    }
  }

  /**
   * Check if a book is marked as read
   * @param {string} bookId - Book ID
   * @returns {boolean} Whether book is read
   */
  function isBookRead(bookId) {
    const readBooks = getReadBooks();
    return readBooks[bookId]?.completed === true;
  }
})();
