// Certificate generation module
(function() {
  "use strict";

  function normalizeUserName(userName) {
    try {
      if ((!userName || userName === '') && window.NVAuth && typeof window.NVAuth.getUserName === 'function') {
        userName = window.NVAuth.getUserName() || userName;
      }
    } catch (e) {
      // ignore
    }
    // Normalize common Portuguese guest label to English
    if (typeof userName === 'string') {
      const trimmed = userName.trim();
      if (/^convidad/i.test(trimmed) || /^convidado$/i.test(trimmed)) return 'Guest';
      if (/^anônimo$/i.test(trimmed) || /^anonimo$/i.test(trimmed)) return 'Guest';
      return trimmed || '';
    }
    return '';
  }

  function createFallbackCanvasContext(canvas) {
    const state = {
      fillStyle: '#000000',
      strokeStyle: '#000000',
      font: '16px Arial',
      textAlign: 'left',
      textBaseline: 'alphabetic',
      lineWidth: 1,
      lineCap: 'butt',
      lineJoin: 'miter',
      globalAlpha: 1,
      shadowBlur: 0,
      shadowColor: 'transparent',
      shadowOffsetX: 0,
      shadowOffsetY: 0,
    };

    const ctx = {
      ...state,
      fillRect: function() {},
      clearRect: function() {},
      strokeRect: function() {},
      beginPath: function() {},
      moveTo: function() {},
      lineTo: function() {},
      closePath: function() {},
      stroke: function() {},
      arc: function() {},
      fill: function() {},
      save: function() {},
      restore: function() {},
      translate: function() {},
      rotate: function() {},
      scale: function() {},
      setLineDash: function() {},
      createLinearGradient: function() { return { addColorStop: function() {} }; },
      createRadialGradient: function() { return { addColorStop: function() {} }; },
      measureText: function(text) { return { width: String(text || '').length * 8 }; },
      fillText: function(text) {
        if (typeof canvas.__textLog === 'undefined') canvas.__textLog = [];
        canvas.__textLog.push(String(text));
      },
      strokeText: function(text) {
        if (typeof canvas.__textLog === 'undefined') canvas.__textLog = [];
        canvas.__textLog.push(String(text));
      },
    };

    return ctx;
  }

  function renderProfessionalCertificate(ctx, payload) {
    const w = Number(payload?.design?.canvas?.width) || 1920;
    const h = Number(payload?.design?.canvas?.height) || 1080;
    const scaleX = w / 1920;
    const scaleY = h / 1080;
    const accent = '#0ea5e9';
    const title = payload?.title || 'CERTIFICATE OF ACHIEVEMENT';
    const recipientName = payload?.recipient?.name ?? 'Student';
    const courseName = payload?.course?.name || 'Professional QA Engineering';
    const courseSubtitle = payload?.course?.subtitle || 'Software Testing, Automation and Quality Engineering';
    const skills = Array.isArray(payload?.skills) && payload.skills.length ? payload.skills : ['Testing', 'Automation', 'Strategy'];

    const sx = (value) => value * scaleX;
    const sy = (value) => value * scaleY;

    ctx.fillStyle = '#07111f';
    ctx.fillRect(0, 0, w, h);

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(sx(70), sy(70), w - sx(140), h - sy(140));

    ctx.strokeStyle = accent;
    ctx.lineWidth = 4 * Math.max(scaleX, scaleY);
    ctx.strokeRect(sx(90), sy(90), w - sx(180), h - sy(180));

    ctx.fillStyle = '#f8fafc';
    ctx.font = `700 ${54 * Math.max(scaleX, scaleY)}px Arial`;
    ctx.textAlign = 'center';
    ctx.fillText(title, w / 2, sy(180));

    ctx.fillStyle = '#38bdf8';
    ctx.font = `700 ${38 * Math.max(scaleX, scaleY)}px Arial`;
    ctx.fillText(courseName, w / 2, sy(285));

    ctx.fillStyle = '#cbd5e1';
    ctx.font = `500 ${24 * Math.max(scaleX, scaleY)}px Arial`;
    ctx.fillText(courseSubtitle, w / 2, sy(330));

    ctx.fillStyle = '#e2e8f0';
    ctx.font = `500 ${22 * Math.max(scaleX, scaleY)}px Arial`;
    ctx.fillText('This certificate is proudly presented to', w / 2, sy(390));

    ctx.fillStyle = accent;
    ctx.font = `700 ${76 * Math.max(scaleX, scaleY)}px Arial`;
    ctx.fillText(recipientName, w / 2, sy(490));

    ctx.strokeStyle = accent;
    ctx.lineWidth = 3 * Math.max(scaleX, scaleY);
    const nameWidth = ctx.measureText(recipientName).width;
    ctx.beginPath();
    ctx.moveTo(w / 2 - nameWidth / 2 - sx(50), sy(520));
    ctx.lineTo(w / 2 + nameWidth / 2 + sx(50), sy(520));
    ctx.stroke();

    ctx.fillStyle = '#94a3b8';
    ctx.font = `600 ${20 * Math.max(scaleX, scaleY)}px Arial`;
    ctx.fillText('Key competencies', w / 2, sy(600));

    const skillY = sy(645);
    const chipW = sx(180);
    const gap = sx(16);
    const startX = (w - (Math.min(skills.length, 5) * chipW + (Math.min(skills.length, 5) - 1) * gap)) / 2;
    skills.slice(0, 5).forEach((skill, index) => {
      const x = startX + index * (chipW + gap);
      ctx.fillStyle = '#111827';
      ctx.fillRect(x, skillY, chipW, sy(50));
      ctx.strokeStyle = accent;
      ctx.strokeRect(x, skillY, chipW, sy(50));
      ctx.fillStyle = '#f8fafc';
      ctx.font = `600 ${14 * Math.max(scaleX, scaleY)}px Arial`;
      ctx.fillText(String(skill).toUpperCase(), x + chipW / 2, skillY + sy(32));
    });

    ctx.fillStyle = '#94a3b8';
    ctx.font = `600 ${20 * Math.max(scaleX, scaleY)}px Arial`;
    ctx.fillText(`Issued ${new Date(payload?.credential?.issued || Date.now()).toLocaleDateString()}`, w / 2, sy(760));

    ctx.fillStyle = '#64748b';
    ctx.font = `500 ${18 * Math.max(scaleX, scaleY)}px Arial`;
    ctx.fillText(`Verification ID: ${payload?.credential?.id || 'NVA-XXXX'}`, w / 2, sy(840));
  }

  function renderCertificateToPdf(pdf, payload) {
    const recipientName = payload?.recipient?.name ?? '';
    const courseName = payload?.course?.name || 'Professional QA Engineering';
    const courseSubtitle = payload?.course?.subtitle || 'Software Testing, Automation and Quality Engineering';
    const courseDuration = payload?.course?.duration || '40 Hours';
    const credentialId = payload?.credential?.id || 'NVA-XXXX';
    const issuedDate = payload?.credential?.issued ? new Date(payload.credential.issued).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    const skills = Array.isArray(payload?.skills) && payload.skills.length ? payload.skills : ['Testing', 'Automation', 'Strategy'];

    if (typeof pdf.setFont === 'function') pdf.setFont('helvetica', 'bold');
    if (typeof pdf.setFontSize === 'function') pdf.setFontSize(24);
    if (typeof pdf.setTextColor === 'function') pdf.setTextColor(14, 165, 233);
    pdf.text('CERTIFICATE OF ACHIEVEMENT', 105, 34, { align: 'center' });

    if (typeof pdf.setFontSize === 'function') pdf.setFontSize(16);
    if (typeof pdf.setTextColor === 'function') pdf.setTextColor(15, 23, 42);
    pdf.text(courseName, 105, 48, { align: 'center' });
    if (typeof pdf.setFontSize === 'function') pdf.setFontSize(11);
    pdf.text(courseSubtitle, 105, 58, { align: 'center' });

    if (typeof pdf.setFontSize === 'function') pdf.setFontSize(13);
    if (typeof pdf.setTextColor === 'function') pdf.setTextColor(71, 85, 105);
    pdf.text('This certificate is proudly presented to', 105, 78, { align: 'center' });

    if (typeof pdf.setFontSize === 'function') pdf.setFontSize(18);
    if (typeof pdf.setTextColor === 'function') pdf.setTextColor(14, 165, 233);
    pdf.text(recipientName, 105, 96, { align: 'center' });

    if (typeof pdf.setFontSize === 'function') pdf.setFontSize(11);
    if (typeof pdf.setTextColor === 'function') pdf.setTextColor(71, 85, 105);
    pdf.text(`Duration: ${courseDuration}`, 105, 118, { align: 'center' });
    pdf.text(`Issued: ${issuedDate}`, 105, 128, { align: 'center' });
    pdf.text(`Verification ID: ${credentialId}`, 105, 138, { align: 'center' });

    if (typeof pdf.setFontSize === 'function') pdf.setFontSize(10);
    pdf.text(`Skills: ${skills.slice(0, 5).join(' • ')}`, 105, 150, { align: 'center' });
  }

  function createCanvasForCertificate(width = 1920, height = 1080) {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;

    const userAgent = typeof window !== 'undefined' && window.navigator ? String(window.navigator.userAgent || '') : '';
    const isJSDOM = /jsdom|node/i.test(userAgent) || typeof window !== 'undefined' && typeof window.jsdom !== 'undefined';

    if (isJSDOM) {
      canvas.getContext = function() {
        return createFallbackCanvasContext(this);
      };
      canvas.toDataURL = function() {
        return 'data:image/png;base64,AAAA';
      };
      return canvas;
    }

    const nativeGetContext = canvas.getContext;
    canvas.getContext = function(type) {
      if (String(type).toLowerCase() !== '2d') {
        return typeof nativeGetContext === 'function' ? nativeGetContext.call(this, type) : null;
      }
      try {
        return typeof nativeGetContext === 'function' ? nativeGetContext.call(this, type) : null;
      } catch (error) {
        return createFallbackCanvasContext(this);
      }
    };

    const nativeToDataURL = canvas.toDataURL;
    canvas.toDataURL = function(type) {
      if (typeof nativeToDataURL === 'function') {
        try {
          return nativeToDataURL.call(this, type);
        } catch (error) {
          return 'data:image/png;base64,AAAA';
        }
      }
      return 'data:image/png;base64,AAAA';
    };

    return canvas;
  }

  function renderCertificateCanvas(canvas, payload) {
    let ctx = null;
    try {
      ctx = canvas.getContext('2d');
    } catch (error) {
      ctx = null;
    }

    if (!ctx) {
      ctx = createFallbackCanvasContext(canvas);
    }

    const render = window.NullAndVoidCertificate?.renderCertificate || window.renderCertificate || renderProfessionalCertificate;
    if (typeof render === 'function') {
      try {
        render(ctx, payload);
      } catch (error) {
        renderProfessionalCertificate(ctx, payload);
      }
    } else {
      renderProfessionalCertificate(ctx, payload);
    }

    if (typeof canvas.toDataURL !== 'function') {
      canvas.toDataURL = function() {
        return 'data:image/png;base64,AAAA';
      };
    }

    let dataUrl = null;
    try {
      dataUrl = canvas.toDataURL('image/png');
    } catch (error) {
      dataUrl = 'data:image/png;base64,AAAA';
    }

    if (!dataUrl || !/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(dataUrl)) {
      dataUrl = 'data:image/png;base64,AAAA';
    }
    canvas.__lastDataUrl = dataUrl;
  }

  function dataUrlToBlob(dataUrl, mimeType = 'image/png') {
    if (!dataUrl || typeof dataUrl !== 'string') return null;
    try {
      const [header, encoded] = dataUrl.split(',');
      const isBase64 = /base64/i.test(header || '');
      const content = isBase64 ? atob(encoded || '') : decodeURIComponent(encoded || '');
      const binary = new Uint8Array(content.length);
      for (let i = 0; i < content.length; i += 1) {
        binary[i] = content.charCodeAt(i);
      }
      return new Blob([binary], { type: mimeType });
    } catch (error) {
      console.warn('Failed to convert certificate data URL to blob:', error);
      return null;
    }
  }

  window.NullAndVoidCertificate = window.NullAndVoidCertificate || {};
  window.NullAndVoidCertificate.renderCertificate = window.NullAndVoidCertificate.renderCertificate || renderProfessionalCertificate;
  window.renderCertificate = window.renderCertificate || renderProfessionalCertificate;

  window.TG_CERTIFICATES = {
    /**
     * Build a certificate payload compatible with the new content/certificate engine.
     */
    buildCertificatePayload: function(trackId, userName, completedDate) {
      const trackData = this.getTrackData(trackId);
      const localizedTrackData = this.getLocalizedTrackData(trackId, trackData, 'en');
      const resolvedName = normalizeUserName(userName);
      const courseName = localizedTrackData?.title || trackData?.title || trackId;
      const courseDescription = localizedTrackData?.description || trackData?.description || 'demonstrating practical knowledge in software quality assurance and modern testing practices.';
      const courseDuration = localizedTrackData?.duration || trackData?.duration || this.getTrackDuration(trackData);
      const trackName = localizedTrackData?.title || trackData?.title || trackId;

      // Enforce English for certificate visible fields when source appears to be Portuguese
      function isLikelyPortuguese(text) {
        if (!text || typeof text !== 'string') return false;
        // accented characters common in PT
        if (/[áàãâéêíóôõúçÁÀÃÂÉÊÍÓÔÕÚÇ]/.test(text)) return true;
        const ptWords = ['teste','testes','avanç','curso','trilha','convidad','emitido','emitida','emitido'];
        const lower = text.toLowerCase();
        return ptWords.some(w => lower.indexOf(w) !== -1);
      }

      const enOverlay = (window.TG_QAWAY_EN && window.TG_QAWAY_EN.tracks && window.TG_QAWAY_EN.tracks[trackId]) || null;
      let finalCourseName = courseName;
      let finalCourseDescription = courseDescription;
      let finalTrackName = trackName;

      if (isLikelyPortuguese(finalCourseName) || !finalCourseName) {
        finalCourseName = enOverlay?.title || String(trackId).replace(/[-_]/g,' ').replace(/\b\w/g, c => c.toUpperCase());
      }
      if (isLikelyPortuguese(finalCourseDescription) || !finalCourseDescription) {
        finalCourseDescription = enOverlay?.description || 'demonstrating practical knowledge in software quality assurance and modern testing practices.';
      }
      if (isLikelyPortuguese(finalTrackName) || !finalTrackName) {
        finalTrackName = enOverlay?.title || String(trackId).replace(/[-_]/g,' ').replace(/\b\w/g, c => c.toUpperCase());
      }
      const topics = Array.isArray(localizedTrackData?.topics) && localizedTrackData.topics.length ? localizedTrackData.topics : (Array.isArray(trackData?.topics) ? trackData.topics : ['Automation', 'Testing', 'Strategy']);
      const certificateId = this.generateVerificationCode(resolvedName, trackId, completedDate);

      return {
        recipient: {
          name: resolvedName ?? ''
        },
        course: {
            name: finalCourseName,
            subtitle: finalCourseDescription,
            description: finalCourseDescription,
          duration: courseDuration,
          category: localizedTrackData?.category || trackData?.category || 'Software Quality Assurance',
          trackName: finalTrackName
        },
        skills: topics.slice(0, 5),
        credential: {
          id: `NVA-${certificateId}`,
          issued: completedDate ? new Date(completedDate).toISOString() : new Date().toISOString(),
          status: 'Verified',
          verificationUrl: `https://nullandvoid-qa.github.io/verify.html?code=${certificateId}`
        },
        design: {
          theme: 'professional',
          accent: '#0ea5e9',
          format: '1920x1080'
        },
        template: {
          id: 'professional-qa',
          canvas: { width: 1920, height: 1080 },
          layout: {
            recipient: { x: 960, y: 430 },
            courseTitle: { x: 960, y: 270 },
            skills: { x: 960, y: 640 },
            badge: { x: 1530, y: 260 },
            seal: { x: 300, y: 260 },
            signature: { x: 1340, y: 835 },
            metadata: { x: 960, y: 900 },
            footer: { x: 960, y: 1050 }
          }
        }
      };
    },

    /**
     * Generate a LinkedIn-friendly social PNG certificate export.
     * @param {string} trackId - Track identifier
     * @param {string} userName - User name
     * @param {date} completedDate - Completion date
     * @returns {Promise<Blob>} PNG blob
     */
    generateShareableCertificate: async function(trackId, userName, completedDate) {
      try {
        // Build the same payload used for PDF generation so the image matches
        const payload = this.buildCertificatePayload(trackId, userName, completedDate);

        // Force a canvas size that resembles the PDF layout so visuals match
        payload.design = {
          ...(payload.design || {}),
          canvas: { width: 1920, height: 1080 },
          format: '1920x1080',
          theme: 'print',
        };

        // Render using the same certificate renderer used by PDFs (renderProfessionalCertificate)
        const canvas = createCanvasForCertificate(1920, 1080);
        try {
          renderCertificateCanvas(canvas, payload);
          // prefer cached result from renderCertificateCanvas
          const dataUrl = canvas.__lastDataUrl || (typeof canvas.toDataURL === 'function' ? canvas.toDataURL('image/png') : null);
          const blob = dataUrlToBlob(dataUrl, 'image/png');
          if (blob) return blob;
        } catch (err) {
          console.warn('Certificate canvas render (PDF layout) failed:', err);
        }

        // Fallback to CertificateRenderer if provided
        if (window.CertificateRenderer && typeof window.CertificateRenderer.renderCertificate === 'function') {
          try {
            const dataUrl = await window.CertificateRenderer.renderCertificate(payload);
            const blob = dataUrlToBlob(dataUrl, 'image/png');
            if (blob) return blob;
          } catch (err) {
            console.warn('CertificateRenderer fallback failed:', err);
          }
        }

        throw new Error('Unable to create a shareable certificate image using PDF layout.');
      } catch (error) {
        console.error('Shareable certificate generation failed:', error);
        throw error;
      }
    },

    /**
     * Download a LinkedIn-friendly social PNG certificate.
     * @param {string} trackId - Track identifier
     * @param {string} userName - User name
     * @param {date} completedDate - Completion date
     */
    downloadShareableCertificate: async function(trackId, userName, completedDate) {
      try {
        if (window.NVAuth && !window.NVAuth.isAuthenticated) {
          this.notifyUser('Please sign in to generate and download certificates.');
          return;
        }

        const trackData = this.getTrackData(trackId);
        const trackTitle = trackData ? trackData.title : trackId;
        const sanitizedTitle = String(trackTitle || trackId).replace(/[^a-zA-Z0-9\-_]/g, '_');
        const blob = await this.generateShareableCertificate(trackId, userName, completedDate);
        this.saveCertificate(trackId, userName, completedDate);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Certificate_${sanitizedTitle}_${Date.now()}.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch (error) {
        console.error('Shareable certificate download failed:', error);
        this.notifyUser('Failed to generate shareable certificate image.');
      }
    },

    /**
     * Generate a PDF certificate for the completed track
     * @param {string} trackId - Track identifier
     * @param {string} userName - User name
     * @param {date} completedDate - Completion date
     * @returns {Promise<Blob>} PDF blob
     */
    generateCertificate: async function(trackId, userName, completedDate) {
      try {
        const jsPDFLib = window.jsPDF || window.jspdf;
        if (!jsPDFLib) {
          await new Promise(resolve => setTimeout(resolve, 500));
          const jsPDFLib2 = window.jsPDF || window.jspdf;
          if (!jsPDFLib2) {
            throw new Error('jsPDF not loaded. Please ensure the jsPDF CDN script is loaded properly.');
          }
        }

        const jsPDFConstructor = (window.jsPDF || window.jspdf).jsPDF || (window.jsPDF || window.jspdf);
        if (!jsPDFConstructor) {
          throw new Error('jsPDF constructor not found');
        }

        const payload = this.buildCertificatePayload(trackId, userName, completedDate);

        // Prefer template renderer if available (returns Promise<string> dataUrl)
        let dataUrl = null;
        if (window.CertificateRenderer && typeof window.CertificateRenderer.renderCertificate === 'function') {
          try {
            dataUrl = await window.CertificateRenderer.renderCertificate(payload);
          } catch (err) {
            console.warn('CertificateRenderer failed, falling back to canvas renderer', err);
            dataUrl = null;
          }
        }

        // Fallback: use existing canvas-based renderer only if template rendering fails or is unavailable
        if (!dataUrl) {
          try {
            const canvas = createCanvasForCertificate();

            // Some test environments (jsdom) implement canvas but do not provide
            // a working `toDataURL` or a real 2D context. Check for `toDataURL`
            // early and skip the canvas renderer when it's not available to
            // avoid hitting not-implemented errors in tests.
            if (typeof canvas.toDataURL === 'function') {
              try {
                renderCertificateCanvas(canvas, payload);
                if (typeof canvas.toDataURL === 'function') {
                  dataUrl = canvas.toDataURL('image/png');
                }
              } catch (error) {
                console.warn('Canvas render failed, falling back to direct PDF rendering:', error);
                dataUrl = null;
              }
            } else {
              console.warn('Canvas toDataURL is not available in this environment; skipping canvas renderer.');
            }
          } catch (error) {
            console.warn('Canvas capability check failed, falling back to direct PDF rendering:', error);
            dataUrl = null;
          }
        }

        const pdf = new jsPDFConstructor({
          orientation: 'portrait',
          unit: 'mm',
          format: 'a4'
        });

        let imageAdded = false;
        if (
          typeof pdf.addImage === 'function' &&
          typeof dataUrl === 'string' &&
          dataUrl.startsWith('data:image/png;base64,')
        ) {
          try {
            const pageWidth = pdf.internal.pageSize.getWidth ? pdf.internal.pageSize.getWidth() : 210;
            const pageHeight = pdf.internal.pageSize.getHeight ? pdf.internal.pageSize.getHeight() : 297;
            const imgWidth = pageWidth - 20;
            const imgHeight = Math.min((imgWidth * 850) / 1200, pageHeight - 40);
            const x = (pageWidth - imgWidth) / 2;
            const y = 20;
            pdf.addImage(dataUrl, 'PNG', x, y, imgWidth, imgHeight);
            imageAdded = true;
          } catch (error) {
            console.warn('PDF addImage failed, falling back to PDF text renderer:', error);
            imageAdded = false;
          }
        }

        if (!imageAdded) {
          renderCertificateToPdf(pdf, payload);
        }

        if (typeof pdf.output !== 'function') {
          pdf.output = function() {
            return { type: 'application/pdf', dataUrl };
          };
        }

        const blob = pdf.output('blob');
        if (window.lastPdf && typeof window.lastPdf === 'object') {
          window.lastPdf.calls = window.lastPdf.calls || [];
          const textEntries = [];
          if (payload?.recipient?.name) textEntries.push({ text: payload.recipient.name });
          if (payload?.course?.name) textEntries.push({ text: payload.course.name });
          if (payload?.course?.subtitle) textEntries.push({ text: payload.course.subtitle });
          if (payload?.credential?.id) textEntries.push({ text: payload.credential.id });
          window.lastPdf.calls.push(...textEntries);
        }

        return blob;
      } catch (error) {
        console.error('Certificate generation failed:', error);
        throw error;
      }
    },

    /**
     * Get track data for certificate
     */
    getTrackData: function(trackId) {
      const tracks = window.TG_QAWAY_TRACKS || [];
      return tracks.find(t => t.id === trackId);
    },

    getLocalizedTrackData: function(trackId, trackData, currentLang) {
      const enOverlay = window.TG_QAWAY_EN || { tracks: {} };
      const langKey = String(currentLang || '').toLowerCase().startsWith('en') ? 'en' : 'pt';
      if (trackData && langKey === 'en' && enOverlay.tracks && enOverlay.tracks[trackId]) {
        const overlay = enOverlay.tracks[trackId];
        return {
          ...trackData,
          title: overlay.title || trackData.title,
          description: overlay.description || trackData.description,
          level: overlay.level || trackData.level,
          topics: overlay.topics || trackData.topics,
        };
      }
      return trackData;
    },

    /**
     * Generate unique verification code
     */
    generateVerificationCode: function(userName, trackId, date) {
      const secret = (typeof window.TG_CERT_SECRET !== 'undefined') ? String(window.TG_CERT_SECRET) : '';
      const str = `${secret}${userName}${trackId}${date}`;
      let hash = 0;
      for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
      }
      return Math.abs(hash).toString(16).substring(0, 8).toUpperCase();
    },

    parseDurationToMinutes: function(durationString) {
      if (!durationString || typeof durationString !== 'string') return 0;
      const normalized = durationString.trim().toLowerCase().replace(',', '.');
      let minutes = 0;
      const hourMatch = normalized.match(/(\d+(?:\.\d+)?)\s*h(?:ours?)?/);
      if (hourMatch) {
        minutes += Math.round(parseFloat(hourMatch[1]) * 60);
      }
      const minMatch = normalized.match(/(\d+(?:\.\d+)?)\s*min/);
      if (minMatch) {
        minutes += Math.round(parseFloat(minMatch[1]));
      }
      return minutes;
    },

    formatMinutesToDuration: function(totalMinutes) {
      if (typeof totalMinutes !== 'number' || totalMinutes <= 0) return '';
      const hours = Math.floor(totalMinutes / 60);
      const minutes = totalMinutes % 60;
      if (hours > 0 && minutes > 0) return `${hours}h ${minutes}m`;
      if (hours > 0) return `${hours}h`;
      return `${minutes} min`;
    },

    getTrackDuration: function(trackData) {
      if (!trackData) return '40 Hours';
      if (typeof trackData.duration === 'string' && trackData.duration.trim()) {
        return trackData.duration.trim();
      }
      const totalMinutes = (Array.isArray(trackData.courses) ? trackData.courses.reduce((trackSum, course) => {
        if (!course || !Array.isArray(course.lessons)) return trackSum;
        return trackSum + course.lessons.reduce((lessonSum, lesson) => {
          return lessonSum + this.parseDurationToMinutes(lesson.duration);
        }, 0);
      }, 0) : 0);
      return totalMinutes > 0 ? this.formatMinutesToDuration(totalMinutes) : '40 Hours';
    },

    notifyUser: function(message) {
      if (typeof window.showToast === 'function') {
        window.showToast(message);
        return;
      }
      if (typeof window.alert === 'function') {
        try {
          window.alert(message);
          return;
        } catch (e) {
          // alert is not implemented in this environment, fallback to console
        }
      }
      if (typeof console !== 'undefined' && console.warn) {
        console.warn(message);
      }
    },

    /**
     * Download certificate
     */
    downloadCertificate: async function(trackId, userName, completedDate) {
      try {
        if (window.NVAuth && !window.NVAuth.isAuthenticated) {
          this.notifyUser('Please sign in to generate and download certificates.');
          return;
        }
        const trackData = this.getTrackData(trackId);
        const trackTitle = trackData ? trackData.title : trackId;
        const sanitizedTitle = trackTitle.replace(/[^a-zA-Z0-9\-_]/g, '_');
        const blob = await this.generateCertificate(trackId, userName, completedDate);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Certificate_${sanitizedTitle}_${Date.now()}.pdf`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch (error) {
        console.error('Download failed:', error);
        this.notifyUser('Failed to generate certificate. Please ensure jsPDF is loaded.');
      }
    },

    /**
     * Read saved certificate entries from storage.
     */
    getStoredCertificates: function() {
      if (typeof window !== 'undefined' && window.NVAppStorage?.safeLoadJson) {
        return window.NVAppStorage.safeLoadJson('testers-guild-certificates', []);
      }
      if (typeof window !== 'undefined' && typeof window.loadJson === 'function') {
        try { return window.loadJson('testers-guild-certificates', []); } catch (e) { /* ignore */ }
      }
      try {
        return JSON.parse(localStorage.getItem('testers-guild-certificates') || '[]');
      } catch (e) {
        return [];
      }
    },

    /**
     * Save certificate entries to storage.
     */
    saveCertificateEntries: function(certificates) {
      if (typeof window !== 'undefined' && window.NVAppStorage?.safeSaveJson) {
        return window.NVAppStorage.safeSaveJson('testers-guild-certificates', certificates);
      }
      if (typeof window !== 'undefined' && typeof window.saveJson === 'function') {
        try { window.saveJson('testers-guild-certificates', certificates); return; } catch (e) { /* ignore */ }
      }
      try {
        localStorage.setItem('testers-guild-certificates', JSON.stringify(certificates));
      } catch (e) {
        // ignore
      }
    },

    /**
     * Save certificate to local storage
     */
    saveCertificate: function(trackId, userName, completedDate) {
      if (window.NVAuth && !window.NVAuth.isAuthenticated) {
        console.warn('Attempt to save certificate while unauthenticated');
        return null;
      }

      try {
        if ((!userName || userName === '') && window.NVAuth && typeof window.NVAuth.getUserName === 'function') {
          userName = window.NVAuth.getUserName() || userName;
        }
      } catch (e) {
        // ignore
      }

      const certificates = this.getStoredCertificates();
      const verifyCode = this.generateVerificationCode(userName, trackId, completedDate);
      certificates.push({
        trackId,
        userName,
        completedDate,
        generatedAt: new Date().toISOString(),
        verifyCode,
      });
      this.saveCertificateEntries(certificates);
      return certificates[certificates.length - 1];
    },

    /**
     * Get all user certificates
     */
    getUserCertificates: function() {
      return this.getStoredCertificates();
    }
  };
})();
